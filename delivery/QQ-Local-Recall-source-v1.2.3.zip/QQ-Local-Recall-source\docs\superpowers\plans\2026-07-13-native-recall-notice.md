# QQ Native Recall Notice Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the detached toast and red bubble badge with one QQ-native-style recall strip immediately above each restored message.

**Architecture:** Keep the existing recovered message ID set and mutation observer. Add a small DOM placement helper that creates or moves one message-specific notice before the corresponding QQ message row; the renderer remains responsible for locating rows and applying the helper.

**Tech Stack:** JavaScript ESM, LiteLoaderQQNT renderer API, Node.js built-in test runner, PowerShell packaging.

## Global Constraints

- The notice text is exactly `对方尝试撤回一条消息`.
- No top-right toast, red badge, or `重新编辑` action remains.
- Do not change IPC interception, recall recovery, cache, persistence, or loader behavior.
- Keep zero external runtime dependencies and the offline security boundary.
- The workspace is not a Git repository; replace commit steps with explicit verification and SHA-256 packaging evidence.

---

### Task 1: Message-specific notice placement

**Files:**
- Modify: `src/ui/recall-notice.mjs`
- Modify: `test/recall-notice.test.mjs`

**Interfaces:**
- Consumes: a DOM-like `document`, the located QQ message row, and a string message ID.
- Produces: `placeRecallNotice(document, row, messageId): boolean` and `removeRecallNotice(document, messageId): void`.

- [ ] **Step 1: Write failing placement and removal tests**

Add tests using minimal fake elements that assert the created notice ID is message-specific, its text is exact, it is inserted before the row, a second call reuses the same node, and removal deletes it.

- [ ] **Step 2: Verify the tests fail for the missing exports**

Run: `node --test test/recall-notice.test.mjs`

Expected: FAIL because `placeRecallNotice` and `removeRecallNotice` are not exported.

- [ ] **Step 3: Implement the minimal DOM helper**

Implement the following behavior without adding configuration:

```js
const noticeId = messageId => `qq-local-recall-notice-${String(messageId)}`;

export function placeRecallNotice(document, row, messageId) {
  if (!row?.parentElement) return false;
  let notice = document.getElementById(noticeId(messageId));
  if (!notice) {
    notice = document.createElement('div');
    notice.id = noticeId(messageId);
    notice.className = 'qq-local-recall-notice';
    const pill = document.createElement('span');
    pill.className = 'qq-local-recall-notice__pill';
    pill.textContent = recallNoticeText(1);
    notice.appendChild(pill);
  }
  row.parentElement.insertBefore(notice, row);
  return true;
}

export function removeRecallNotice(document, messageId) {
  document.getElementById(noticeId(messageId))?.remove();
}
```

- [ ] **Step 4: Verify the focused tests pass**

Run: `node --test test/recall-notice.test.mjs`

Expected: all recall notice tests PASS.

### Task 2: Renderer integration and native styling

**Files:**
- Modify: `src/renderer.mjs`
- Create: `test/renderer-notice.test.mjs`

**Interfaces:**
- Consumes: `placeRecallNotice` and `removeRecallNotice` from Task 1.
- Produces: message-row lookup and native-style rendering through the existing `onRecovered` path.

- [ ] **Step 1: Write a failing renderer regression test**

Read `src/renderer.mjs` as text and assert that it imports and calls the placement helper, calls the removal helper during record deletion, contains the native notice classes, and no longer contains `qq-local-recall-toast`, `qq-local-recall-badge`, or `showRecallNotice`.

- [ ] **Step 2: Verify the renderer test fails against version 1.1.0**

Run: `node --test test/renderer-notice.test.mjs`

Expected: FAIL because the old toast and badge implementation remains.

- [ ] **Step 3: Make the minimal renderer change**

- Replace the helper import with `recallNoticeText`, `placeRecallNotice`, and `removeRecallNotice` as required.
- Change row lookup to prefer `document.getElementById(`ml-${messageId}`)` and otherwise use the direct message content element's closest message row or parent.
- Replace badge append logic with `placeRecallNotice(document, row, messageId)`.
- Remove all toast creation, timeout, animation, and toast CSS.
- Add only the two native classes:

```css
.qq-local-recall-notice {
  display: flex; justify-content: center; width: 100%; margin: 8px 0;
  color: var(--text_secondary, #8b8f97); font-size: 12px; line-height: 20px;
  user-select: none; pointer-events: none;
}
.qq-local-recall-notice__pill {
  padding: 2px 10px; border-radius: 12px;
  background: var(--background_secondary, rgb(0 0 0 / 8%));
}
```

- Ignore `attemptedIds` in the renderer because the message-specific strip is driven by recovered message IDs and must also reappear after node reconstruction.
- Remove the strip in `replaceDeletedMessage` before replacing the restored message content.

- [ ] **Step 4: Run focused and full tests**

Run: `node --test test/renderer-notice.test.mjs test/recall-notice.test.mjs`

Expected: PASS.

Run: `npm test`

Expected: all tests PASS with zero failures.

### Task 3: Version, documentation, package, and deployment

**Files:**
- Modify: `package.json`
- Modify: `manifest.json`
- Modify: `scripts/install.ps1`
- Modify: `scripts/package.ps1`
- Modify: `README.md`
- Modify: `docs/architecture.md`
- Modify: `docs/testing.md`
- Modify: `progress.md`
- Regenerate: `delivery/QQ-Local-Recall-v1.2.0.zip`
- Regenerate: `delivery/QQ-Local-Recall-source-v1.2.0.zip`
- Regenerate: `delivery/SHA256SUMS.txt`
- Deploy: `C:\Users\sanha\Documents\LiteLoaderQQNT\plugins\qq_local_recall`

**Interfaces:**
- Consumes: the verified renderer implementation from Task 2.
- Produces: version `1.2.0` source, installable package, hashes, and installed plugin files.

- [ ] **Step 1: Update only behavior-affected documentation and version fields**

Set the project, manifest, installer, and package version to `1.2.0`. Document that the notice is a centered strip above the corresponding restored message and that the old top-right notification is removed.

- [ ] **Step 2: Run full automated verification**

Run: `npm test`

Expected: zero failures.

Run: `npm run check`

Expected: static audit and package validation both exit with code 0.

- [ ] **Step 3: Package and verify hashes**

Run: `npm run package`

Expected: both `v1.2.0` ZIP files and a refreshed `delivery/SHA256SUMS.txt` are generated; old version ZIPs are absent if the packaging script performs version cleanup.

- [ ] **Step 4: Deploy without deleting recall data**

Fully exit QQ, copy the verified plugin package contents over `C:\Users\sanha\Documents\LiteLoaderQQNT\plugins\qq_local_recall`, preserve its `data` directory, then restart QQ. Compare SHA-256 for installed source files against the workspace.

- [ ] **Step 5: Append the implementation record**

Append one `progress.md` entry containing the behavior change, exact test outputs, changed-file list, installed version, and rollback command using `delivery/backup/9.9.32-50969-20260713-220325`.

- [ ] **Step 6: Request real interaction acceptance**

Ask the user to have the second account recall one new text message. Acceptance requires the centered strip to appear immediately above that exact message and no top-right plugin notification to appear.

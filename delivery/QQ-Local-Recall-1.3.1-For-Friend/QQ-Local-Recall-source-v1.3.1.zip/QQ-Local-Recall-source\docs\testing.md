# 验证矩阵

## Automated

- Node tests：消息筛选、缓存淘汰、撤回识别、自己撤回放行、跨重启恢复、持久化、损坏文件、容量排序、整组删除、IPC 边界和管理页模型。
- 提示测试：验证提示插入对应消息行正上方、按消息 ID 去重、按记录删除，以及渲染层不再包含右上角通知或气泡红标。
- Static audit：生产源码无网络、子进程、动态执行和原生模块引用。
- Package validation：Manifest V4、注入文件、CSP、零依赖和交付 ZIP 内容。
- 存储路径测试：路径原子配置、无效/UNC 路径回退、记录目录迁移、管理页面显示和文件夹选择 IPC。
- 管理窗口 Preload 回归测试：确认使用独立的 `qqLocalRecallManager` 桥接，避免 LiteLoader 全局 Preload 覆盖 `chooseStoragePath`。
- 好友显示测试：内部 `u_...` UID 转换为“好友（QQ号）”可读标签。

## Live acceptance

使用第二账号分别在好友和群聊执行：

1. 发送并撤回纯文字。
2. 发送并撤回 QQ 表情。
3. 回复一条消息后撤回回复。
4. 验证原气泡保留并显示“已撤回”。
5. 验证“对方尝试撤回一条消息”灰色提示条位于该气泡正上方，且右上角没有插件通知。
6. 切换会话、重启 QQ 后再次确认。
7. 在记录管理中按容量找到对应会话，整组删除并重新进入聊天。
8. 当前账号自行撤回一条消息，确认仍采用 QQ 原行为。
9. 发送并撤回图片，确认插件不恢复且 QQ 不崩溃。
10. 在管理窗口修改记录目录，确认已有记录迁移、重启 QQ 后仍从新目录读取。

## QQ 9.9.32-51246 compatibility

- Dry Run 必须识别 `9.9.32-51246`，并确认官方入口为 `./application.asar/app_launcher/index.js`。
- `application.asar` 必须匹配已验证的 51246 SHA-256；脚本不修改 ASAR，也不替换 `QQ.exe`。
- LiteLoader 启动链先加载本地入口，再转发到 ASAR 内的官方 `app_launcher/index.js`。
- 实际安装前备份 `package.json`、已有本地入口、桥接和插件；安装异常调用回滚脚本恢复备份。
- 2026-07-16 实机验证：43 项 Node 测试、静态审核、包校验与 Dry Run 通过；安装后 QQ 启动为 8 个正常响应进程，设置中出现 LiteLoaderQQNT、“QQ 本地防撤回”和“管理记录”入口。
- 安装前后 `QQ.exe` 与 `application.asar` SHA-256 一致，插件 1.3.1 源码逐文件一致，撤回数据文件保持 9 个；回滚点为 `delivery/backup/9.9.32-51246-20260716-005324`。

## Local installation evidence, 2026-07-13

- 安装前 Dry Run 正确识别 `9.9.32-50969`，且确认不会替换 `QQ.exe`。
- 首次启动定位到 LiteLoader 1.4.1 的 `Dirent.path` 兼容错误；加入 `parentPath ?? path` 修正后 QQ 主界面成功启动，插件数据目录成功创建。
- LiteLoader 设置列表中已识别“QQ 本地防撤回”，插件设置页已显示“管理记录”入口。
- Preload 回归测试确认主 QQ 页面和沙箱管理窗口不依赖本地模块加载。
- 完整执行 `rollback.ps1 -RemoveData -RemoveLoader`，确认恢复官方 `application.asar` 入口、移除加载桥接和加载器目录，原 QQ 能启动。
- 再次执行修正版 `install.ps1`，确认兼容补丁、插件、加载入口和桥接哈希正确，QQ 启动未出现 JavaScript Error 窗口，插件数据目录成功创建。

## 1.3.1 管理窗口回归证据, 2026-07-14

- 根因定位：LiteLoader 会把插件主 Preload 注入所有 BrowserWindow；管理窗口原先再次注册 `window.qqLocalRecall`，被先加载的主 QQ API 占用，导致 `chooseStoragePath` 缺失。
- 修复验证：管理 Preload 改用独立的 `window.qqLocalRecallManager`，43 项 Node 测试、静态安全审核和包校验全部通过。
- 实机验证：QQ `9.9.32-50969` 重启后管理窗口正常显示记录位置；点击“修改位置”成功打开原生文件夹选择器，取消后窗口无报错，数据目录保持不变。
- 1.2.0 覆盖部署后，15 个已安装源码文件与工作区逐文件 SHA-256 一致，QQ 启动后存在 8 个正常进程；原生风格提示位置仍需第二账号执行一次新消息撤回完成视觉验收。
- 1.2.0 实机验收确认消息恢复成功但原生提示未出现；DOM 诊断证明 QQ 9.9.32 消息行结构为 `.ml-item#原始消息ID`，而 1.2.0 错误查找 `#ml-消息ID`。1.2.1 增加真实结构回归测试并修正定位器。
- 1.2.1 稳定性复核发现提示节点已存在时仍重复 `insertBefore`，会被全局 `MutationObserver` 反复触发并造成 QQ 未响应；1.2.2 增加“不重复移动”回归测试并修复。
- 1.2.2 复核发现记录整组删除路径仍只查找 `ml-消息ID`，无法在真实 `.ml-item#原始消息ID` 中替换当前气泡；1.2.3 增加内容定位回归测试并修复。
- 好友/群聊真实撤回、跨重启恢复及整组删除仍需要当前账号完成交互式登录后，用第二账号执行验收矩阵。

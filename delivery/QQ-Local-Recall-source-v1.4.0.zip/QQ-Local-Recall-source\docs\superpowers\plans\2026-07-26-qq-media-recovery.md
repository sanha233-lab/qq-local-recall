# QQ Media Recovery 1.4.0 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Prevent loading placeholders from becoming permanent recalled images and add default-on, user-disableable QQ-session media recovery for missing pictures.

**Architecture:** Keep the existing fixed `persist-rendered-media` IPC and content-addressed `MediaStore`. The renderer emits one candidate per real picture container; the main process validates that candidate against `RecallProcessor.pendingMedia`, then either saves a local/Canvas image or invokes a dedicated fetch service with `event.sender.session.fetch`. A settings file in the fixed plugin data directory controls only network recovery.

**Tech Stack:** Node.js CommonJS/ES modules, Electron IPC/session fetch, Node test runner, PowerShell delivery scripts.

## Global Constraints

- Scope is images only; do not add voice, video, file, or merged-forward recovery.
- Never rewrite or delete existing formal QQ records or media; historical invalid fallback images are ignored only while reading.
- Network requests use only `event.sender.session.fetch`, with no global or Node-network fallback.
- Require HTTPS, allowed initial host, exact `/download`, `appid`, `fileid`, `spec`, `rkey`, pending `fileUuid`, at most two redirects, 10-second timeout, 20 MiB maximum, and supported image magic bytes.
- Full temporary URLs, `fileid`, and `rkey` remain memory-only and never enter records, logs, or IPC results.
- Version is `1.4.0`; `progress.md` is append-only and every implementation task records tests and rollback instructions.

---

### Task 1: Picture Candidate Capture And Static PNG Validation

**Files:**
- Modify: `src/ui/media-capture.mjs`
- Modify: `src/core/media-store.js`
- Modify: `src/core/processor.js`
- Test: `test/media-capture.test.mjs`
- Test: `test/media-store.test.js`
- Test: `test/processor.test.js`

**Interfaces:**
- Produces: renderer candidates `{ sourceUrl, node }` or `{ mimeType: 'image/png', bytes, width, height, node }` in media-container DOM order.
- Produces: `MediaStore.saveBytes(value, declaredMime, staticFallback, dimensions?)` and `MediaStore.resolve(reference, expectedDimensions?)` with a 15% aspect-ratio limit for static fallbacks.
- Consumes: pending picture dimensions from `picElement.picWidth` and `picElement.picHeight`.

- [ ] **Step 1: Write failing capture tests**

Add cases proving `querySelectorAll` is limited to picture containers, each container yields at most one `img`/`canvas`, video/SVG/avatar/gray-tip/loading/spinner nodes do not consume a media index, HTTPS is preserved before load completion, and Canvas output includes positive natural dimensions.

- [ ] **Step 2: Run capture tests and verify RED**

Run: `node --test test/media-capture.test.mjs`

Expected: failures show the old `img,canvas,video,svg` scan, missing HTTPS candidate, and missing `width`/`height`.

- [ ] **Step 3: Implement the minimal capture filter**

Use real media containers in DOM order, prefer `appimg:` then complete HTTPS `img`, and only call Canvas for completed image/canvas content. Return the DOM node only to renderer code and strip it before IPC.

- [ ] **Step 4: Run capture tests and verify GREEN**

Run: `node --test test/media-capture.test.mjs`

- [ ] **Step 5: Write failing PNG-dimension tests**

Create literal PNG IHDR fixtures for `60 x 60`, `864 x 1920`, and a small square expression. Assert a `60 x 60` fallback is rejected for `864 x 1920`, a matching portrait fallback is accepted, missing original dimensions do not reject a small expression, and historical `staticFallback: true` references are ignored on read when their IHDR aspect ratio is wrong.

- [ ] **Step 6: Run store/processor tests and verify RED**

Run: `node --test test/media-store.test.js test/processor.test.js`

Expected: failures show no capture-dimension validation and no historical IHDR validation.

- [ ] **Step 7: Implement minimal PNG dimension validation**

Read PNG width/height from bytes 16-23 after validating the PNG signature and IHDR marker. Compare `width / height` to `picWidth / picHeight` using `Math.abs(actual - expected) / expected <= 0.15`; require positive integer capture dimensions and perform no absolute minimum-size check.

- [ ] **Step 8: Run store/processor tests and verify GREEN**

Run: `node --test test/media-store.test.js test/processor.test.js`

- [ ] **Step 9: Append progress evidence**

Append one `progress.md` entry listing changed files, both test commands, and rollback to the pre-task commit.

### Task 2: Fixed Settings And Restricted QQ Media Fetch

**Files:**
- Create: `src/core/settings.js`
- Create: `src/core/qq-media-fetch.js`
- Create: `test/settings.test.js`
- Create: `test/qq-media-fetch.test.js`
- Modify: `src/core/processor.js`

**Interfaces:**
- Produces: `readSettings(configDir): { version: 1, networkMediaRecovery: boolean }` and `writeSettings(configDir, settings)` using `settings.json` plus same-directory temporary rename.
- Produces: `fetchQqMedia({ fetch, sourceUrl, expectedFileUuid, signal? }): Promise<{ bytes, mimeType }>`.
- Produces: `RecallProcessor.pendingMediaElement(messageId, mediaIndex)` to expose only the current pending picture element needed for validation.

- [ ] **Step 1: Write failing settings tests**

Assert missing, malformed, and field-missing files default to `true`; writing `false` survives restart; the write leaves no temporary file; and non-boolean updates throw.

- [ ] **Step 2: Run settings tests and verify RED**

Run: `node --test test/settings.test.js`

- [ ] **Step 3: Implement the minimal settings module**

Persist exactly `{ "version": 1, "networkMediaRecovery": boolean }` in the fixed config directory and atomically rename a process-specific temporary file.

- [ ] **Step 4: Run settings tests and verify GREEN**

Run: `node --test test/settings.test.js`

- [ ] **Step 5: Write failing fetch validation tests**

Use injected fake responses to cover protocol, port, credentials, initial host, exact path, numeric `appid`, exact pending `fileid`, numeric `spec`, non-empty `rkey`, HTTP failure, timeout signal, redirect limit/host, streamed 20 MiB limit, misleading response MIME, unknown magic, and valid GIF/PNG/JPEG/WebP bytes. Assert returned values and captured diagnostics contain no URL or query secret.

- [ ] **Step 6: Run fetch tests and verify RED**

Run: `node --test test/qq-media-fetch.test.js`

- [ ] **Step 7: Implement the restricted fetch service**

Validate the initial URL before invoking the injected function. Call it with `redirect: 'manual'` and an abort signal, validate every redirect URL before the next request, enforce 10 seconds for each request, stop reading after 20 MiB, and classify the final buffer using existing image magic-byte logic.

- [ ] **Step 8: Run fetch tests and verify GREEN**

Run: `node --test test/qq-media-fetch.test.js`

- [ ] **Step 9: Add and test the pending-media lookup**

Write a failing processor test that returns the exact picture/market-face element for a valid pending index and rejects missing/out-of-range identities, implement the narrow lookup, then rerun `node --test test/processor.test.js`.

- [ ] **Step 10: Append progress evidence**

Append one `progress.md` entry with tests, changed files, and executable rollback.

### Task 3: IPC Integration, Retry State, Current Bubble, And Manager Toggle

**Files:**
- Modify: `src/main-plugin.js`
- Modify: `src/preload-api.js`
- Modify: `src/preload.js`
- Modify: `src/renderer.mjs`
- Modify: `src/ui/manager-preload.js`
- Modify: `src/ui/manager.html`
- Modify: `src/ui/manager.mjs`
- Modify: `src/ui/manager.css`
- Test: `test/main-plugin.test.js`
- Test: `test/preload-api.test.js`
- Test: `test/preload-entry.test.js`
- Create: `test/media-retry.test.mjs`
- Modify: `test/manager-storage-ui.test.mjs`

**Interfaces:**
- Extends fixed media IPC Canvas input with positive integer `width` and `height`; HTTPS input remains `{ messageId, mediaIndex, sourceUrl }`.
- Adds fixed setting channels `qq-local-recall:get-settings` and `qq-local-recall:update-settings`.
- Successful media persistence returns `{ ok: true, reference, displayUrl }`; it never returns the source URL.
- Produces retry scheduling at `0`, `250`, `1000`, `3000`, and `8000` milliseconds, stopping per media index on success.

- [ ] **Step 1: Write failing main-process integration tests**

Assert Canvas dimensions are required and checked against pending dimensions; HTTPS uses the invoking event's `sender.session.fetch`; disabling settings prevents fetch; missing session fetch falls through without a global request; the pending `fileUuid` is required; and success returns only a validated local display URL plus public reference.

- [ ] **Step 2: Run main integration tests and verify RED**

Run: `node --test test/main-plugin.test.js`

- [ ] **Step 3: Implement minimal IPC integration**

Read settings from `storageConfigDir`, register the two setting handlers, branch fixed media input into `appimg:`, HTTPS fetch, and Canvas paths, validate against the pending element before persistence, then reuse `MediaStore` and `RecallProcessor.persistRenderedMedia`.

- [ ] **Step 4: Run main integration tests and verify GREEN**

Run: `node --test test/main-plugin.test.js`

- [ ] **Step 5: Write failing preload and manager tests**

Assert only the two fixed setting calls are exposed, the manager contains a checked checkbox labelled `缺失媒体自动回源`, changing it persists a boolean, and renderer media IPC sends no DOM node.

- [ ] **Step 6: Run preload/manager tests and verify RED**

Run: `node --test test/preload-api.test.js test/preload-entry.test.js test/manager-storage-ui.test.mjs`

- [ ] **Step 7: Implement the fixed APIs and toggle UI**

Add the channels to `preload-api.js`, expose them only in the manager preload, load the setting on startup, and persist checkbox changes. Keep the manager CSP `connect-src 'none'`.

- [ ] **Step 8: Run preload/manager tests and verify GREEN**

Run: `node --test test/preload-api.test.js test/preload-entry.test.js test/manager-storage-ui.test.mjs`

- [ ] **Step 9: Write failing renderer retry tests**

Extract a small renderer-side retry coordinator exercised with a fake clock: duplicate successful URL/hash submits once, failed attempts remain eligible, success applies `displayUrl` and stops, and final loading-state failure replaces the matching node with `图片暂不可用`.

- [ ] **Step 10: Run retry tests and verify RED**

Run: `node --test test/media-retry.test.mjs`

- [ ] **Step 11: Implement finite retry and bubble update**

Schedule the five approved offsets, track completion per `messageId:mediaIndex`, remove a key after IPC rejection, apply only the returned `displayUrl` to the candidate node, and replace a still-loading node after the final attempt.

- [ ] **Step 12: Run retry and renderer tests and verify GREEN**

Run: `node --test test/media-retry.test.mjs test/renderer-notice.test.mjs`

- [ ] **Step 13: Append progress evidence**

Append one `progress.md` entry listing tests, files, and rollback.

### Task 4: Audit, Documentation, Version, Delivery, And Release Commit

**Files:**
- Modify: `scripts/static-audit.js`
- Modify: `scripts/validate-package.js`
- Modify: `scripts/package.ps1`
- Modify: `README.md`
- Modify: `docs/architecture.md`
- Modify: `docs/security-audit.md`
- Modify: `docs/installation.md`
- Modify: `docs/friend-install.md`
- Modify: `docs/testing.md`
- Modify: `package.json`
- Modify: `manifest.json`
- Regenerate: `delivery/QQ-Local-Recall-v1.4.0.zip`
- Regenerate: `delivery/QQ-Local-Recall-source-v1.4.0.zip`
- Regenerate: `delivery/SHA256SUMS.txt`
- Modify: `progress.md`

**Interfaces:**
- Static audit permits controlled networking only in `src/core/qq-media-fetch.js` and verifies every required restriction marker.
- Package validation expects version `1.4.0`, the fetch/settings files, fixed manager CSP, package contents, and exact SHA-256 entries.

- [ ] **Step 1: Write the audit expectation before changing its implementation**

Run `npm run check` after adding the production fetch module and confirm RED because the old audit forbids its controlled network usage or the old delivery metadata is stale.

- [ ] **Step 2: Implement the narrow static audit exception**

Keep all current bans for every other `src/` file. For `qq-media-fetch.js`, allow only injected fetch usage and assert source-level presence of HTTPS, approved hosts, exact download path, `fileid`, `rkey`, redirect count, 10-second timeout, 20 MiB cap, and magic-byte classification.

- [ ] **Step 3: Update behavior and deployment documentation**

Document default-on networking, manager switch, exact request boundary, ephemeral credentials, fallback behavior, historical PNG read validation, new automated cases, and the five-step new-sample real-machine acceptance matrix.

- [ ] **Step 4: Bump version and update delivery checks**

Set `package.json` and `manifest.json` to `1.4.0`; make validation and package inclusion cover `settings.js` and `qq-media-fetch.js`.

- [ ] **Step 5: Run focused and full verification before packaging**

Run: `npm test`

Run: `node scripts/static-audit.js`

Run: `git diff --check`

Run a repository scan for `rkey=`, complete QQ download URL literals outside fetch tests/design documentation, and accidental URL logging.

- [ ] **Step 6: Regenerate delivery artifacts on D drive**

Before invoking npm/PowerShell packaging, check C/D free space and set `TEMP`, `TMP`, and npm cache variables to a task-specific D-drive directory for the command. Run `npm run package` and confirm the two `1.4.0` archives and `SHA256SUMS.txt` are regenerated without modifying the vendored prerequisites.

- [ ] **Step 7: Run final delivery verification**

Run: `npm test`

Run: `npm run check`

Run: `git diff --check`

Run the sensitive-value scan again and inspect `git status --short` plus `git diff --stat`.

- [ ] **Step 8: Append final progress evidence**

Append the prescribed entry with complete verification counts, changed-file descriptions, the real-machine acceptance gap, and rollback to `c0f0282a006f9e59592beb5acc86dcb8d88c7c33` or the release commit revert.

- [ ] **Step 9: Commit and push**

Create one clear `1.4.0` implementation commit after all verification is fresh, push `main` to `origin/main`, and confirm the remote branch resolves to the new commit.
